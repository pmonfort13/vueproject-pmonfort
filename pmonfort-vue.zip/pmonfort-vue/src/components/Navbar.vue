<template>
  <div :class="{'fixed top-0 left-0 w-full z-10 backdrop-filter backdrop-blur-lg bg-opacity-20 text-black shadow-lg': transparent, 'bg-gradient-to-r from-red-500 to-yellow-500 text-white shadow-md': !transparent}" class="h-16 flex items-center justify-center"> <!-- Añade la clase "h-16" y "flex items-center justify-center" para centrar verticalmente -->
    <div class="container mx-auto px-4">
      <button @click="drawer = !drawer" class="md:hidden p-4 focus:outline-none rounded-lg">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-8 h-8">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="10" d="M4 6h16M4 12h16m-7 6h7"></path>
        </svg>
      </button>

      <div class="flex justify-between items-center">
        <div class="hidden md:flex space-x-6">
          <router-link to="/" class="flex items-center text-lg font-semibold hover:text-red-200  duration-300 ease-in-out">
            Home
          </router-link>
          <router-link to="/about" class="flex items-center text-lg font-semibold hover:text-red-200  duration-300 ease-in-out">
            Pokedex
          </router-link>
        </div>
      </div>
    </div>

    <div v-if="drawer" class="md:hidden backdrop-blur-lg backdrop-filter bg-opacity-20 p-4 text-black">

      <router-link to="/" class="block py-2 flex items-center space-x-2 text-lg font-semibold hover:text-red-200 transition-colors duration-300 ease-in-out" @click.native="drawer = false">
        Home
      </router-link>
      <router-link to="/about" class="block py-2 flex items-center space-x-2 text-lg font-semibold hover:text-red-200 transition-colors duration-300 ease-in-out" @click.native="drawer = false">
        About
      </router-link>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const drawer = ref(false);
const router = useRouter();
</script>
