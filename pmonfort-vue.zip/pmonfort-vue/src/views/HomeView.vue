<template>
  <div class="home-page">
    <div class="background">
      <img src="@/components/icons/fons.jpg" alt="Background image">
    </div>
    <div class="content">
      <h1 class="title">POKEDEX MP09</h1>
      <p class="subtitle">Feta per Pau Monfort</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HomePage'
};
</script>

<style scoped>
.home-page {
  position: relative;
  height: 100vh;
  overflow: hidden;
}

.background {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}

.background img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  color: rgb(255, 255, 255);
}

.title {
  font-size: 3rem;
  font-weight: bold;
  padding: 10px 20px; 
  text-shadow: 6px 6px 10px rgba(0, 1, 0, 0.5); 
  -webkit-text-stroke: 2px black; 
}

.subtitle {
  font-size: 1rem;
  font-weight: bold;
  padding: 10px 20px; 
  text-shadow: 6px 6px 10px rgba(0, 1, 0, 0.5); 
  
}
</style>
