<template>
  <div class="min-h-screen bg-gray-100">
    <div class="py-10">
      <h1 class="text-3xl font-semibold text-center">Cerca Pokémon (GEN 1)</h1>
    </div>

    <div class="search-container p-6 mx-auto max-w-7xl">
      <input type="text" v-model="searchQuery" @input="searchPokemon" placeholder="Cerca Pokémon..." class="w-full px-4 py-2 text-gray-800 placeholder-gray-500 bg-white border border-gray-300 rounded shadow-sm focus:outline-none focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">

      <div class="pokemon-grid mt-6 grid gap-6 grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        <div class="pokemon-card bg-white rounded-lg shadow-md overflow-hidden cursor-pointer" v-for="pokemon in filteredPokemon" :key="pokemon.id" @click="goToPokemonDetail(pokemon.id)" style="height: 100%;">
          <div class="w-full h-56 flex justify-center items-center overflow-hidden">
            <img :src="pokemon.sprites.front_default" alt="Imatge del Pokémon" class="min-h-full min-w-full object-cover object-center">
          </div>
          <div class="p-4">
            <p class="text-lg font-semibold text-gray-800">{{ pokemon.name }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
  import { ref, computed } from 'vue';
  import { useRouter } from 'vue-router';

  const searchQuery = ref('');
  const allPokemon = ref([]);
  const router = useRouter();

  const apiUrl = 'https://pokeapi.co/api/v2/pokemon/';

  const handleResponse = async (response) => {
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message);
    }
    return response.json();
  };

  const handleError = (error) => {
    alert('Error, consulta la consola');
    console.error(error);
  };

  const fetchFirstGenPokemon = async () => {
    try {
      for (let i = 1; i <= 151; i++) {
        const response = await fetch(apiUrl + i);
        const data = await handleResponse(response);
        allPokemon.value.push({
          id: data.id,
          name: data.name,
          sprites: data.sprites
        });
      }
    } catch (error) {
      handleError(error);
    }
  };

  const filteredPokemon = computed(() => {
    const searchText = searchQuery.value.toLowerCase();
    if (!searchText) {
      return allPokemon.value;
    } else {
      return allPokemon.value.filter(pokemon => pokemon.name.toLowerCase().includes(searchText));
    }
  });

  const goToPokemonDetail = (id) => {
    router.push({ name: 'aboutdetail', params: { id } });
  };

  fetchFirstGenPokemon();
</script>
