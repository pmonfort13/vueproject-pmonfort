<template>
  <div v-if="pokemon">
    <div class="relative banner h-60 lg:h-96" :style="{ backgroundImage: `url(${pokemon.sprites.other['official-artwork'].front_default || '/public/img/banner.png'})` }">
      <div class="absolute inset-0 bg-black bg-opacity-30"></div>
      <div class="flex justify-center items-center h-full relative">
        <div class="bg-black bg-opacity-50 px-4 py-2 rounded">
          <h1 class="text-white text-2xl lg:text-4xl font-bold">{{ pokemon.name }}</h1>
        </div>
      </div>
    </div>

    <div class="pokemon-detail bg-white shadow-lg max-w-5xl mx-auto mt-8 p-8 rounded-lg">
      <div class="flex flex-col lg:flex-row gap-4">
        <img :src="pokemon.sprites.front_default" :alt="`Imagen de ${pokemon.name}`" class="pokemon-image w-full lg:w-1/4 max-h-80 rounded-lg">
        <div class="flex flex-col p-4 lg:w-3/4">
          <p class="text-gray-700 text-base leading-relaxed description">{{ pokemon.description }}</p>
          <p class="text-gray-700 text-base leading-relaxed mt-4">Altura: {{ pokemon.height / 10 }}m | Peso: {{ pokemon.weight / 10 }}kg</p>
          <p class="text-gray-700 text-base leading-relaxed">Tipo(s): {{ pokemon.types.map(type => type.type.name).join(', ') }}</p>
          <p class="text-gray-700 text-base leading-relaxed mt-4 font-semibold">Características:</p>
          <ul class="list-disc pl-4">
            <li v-for="stat in pokemon.stats" :key="stat.stat.name">{{ stat.stat.name }}: {{ stat.base_stat }}</li>
          </ul>
        </div>
      </div>
    </div>

    <div class="flex justify-center mt-8">
      <button @click="closePokemonDetail" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-4">Tanca</button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';

const route = useRoute();
const router = useRouter();
const pokemon = ref(null);

onMounted(() => {
  fetchPokemonDetail();
});

onUnmounted(() => {
});

watch(() => route.params.id, (newId, oldId) => {
  if (newId !== oldId) {
    fetchPokemonDetail();
  }
});

const fetchPokemonDetail = async () => {
  const id = route.params.id;
  const url = `https://pokeapi.co/api/v2/pokemon/${id}`;
  const speciesUrl = `https://pokeapi.co/api/v2/pokemon-species/${id}`;

  try {
    const [response, speciesResponse] = await Promise.all([fetch(url), fetch(speciesUrl)]);
    if (!response.ok || !speciesResponse.ok) throw new Error('Network response was not ok');

    const data = await response.json();
    const speciesData = await speciesResponse.json();

    pokemon.value = {
      name: data.name,
      sprites: data.sprites,
      height: data.height,
      weight: data.weight,
      types: data.types,
      stats: data.stats,
      description: speciesData.flavor_text_entries.find(entry => entry.language.name === 'en').flavor_text
    };
  } catch (error) {
    console.error('Error fetching pokemon details:', error);
  }
};

const closePokemonDetail = () => {
  router.go(-1); 
};
</script>

<style scoped>
.banner {
  border-bottom-left-radius: 15px;
  border-bottom-right-radius: 15px;
}

.pokemon-image {
  object-fit: cover;
}

.description {
  overflow: auto;
  max-height: 300px;
}
</style>
